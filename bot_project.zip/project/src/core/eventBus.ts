import { EventEmitter } from 'events';
import { TokenEvent, TradeEvent, FilterResult, PerformanceMetrics } from '../types/index.js';
import { logDetectedPool, logPerformanceMetric } from '../utils/logger.js';

/**
 * High-performance event bus for processing 1000+ events/sec
 * Uses EventEmitter with optimized listeners and batching
 */
export class EventBus extends EventEmitter {
  private static instance: EventBus;
  private eventCounts = new Map<string, number>();
  private lastReset = Date.now();
  private batchBuffer: TokenEvent[] = [];
  private batchTimer: NodeJS.Timeout | null = null;
  private readonly BATCH_SIZE = 100;
  private readonly BATCH_TIMEOUT = 50; // 50ms batching

  private constructor() {
    super();
    this.setMaxListeners(1000); // High limit for performance
    
    // Performance monitoring
    setInterval(() => {
      this.emitPerformanceMetrics();
    }, 10000); // Every 10 seconds
  }

  static getInstance(): EventBus {
    if (!EventBus.instance) {
      EventBus.instance = new EventBus();
    }
    return EventBus.instance;
  }

  /**
   * Emit token detection event with batching for performance
   */
  emitTokenEvent(event: TokenEvent): void {
    this.incrementCounter('token_detected');
    
    // Add to batch buffer
    this.batchBuffer.push(event);
    
    // Process batch if full or start timer
    if (this.batchBuffer.length >= this.BATCH_SIZE) {
      this.processBatch();
    } else if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.processBatch();
      }, this.BATCH_TIMEOUT);
    }
    
    logDetectedPool(event.mintAddress, event.source);
  }

  /**
   * Process batched token events for high throughput
   */
  private processBatch(): void {
    if (this.batchBuffer.length === 0) return;
    
    const batch = [...this.batchBuffer];
    this.batchBuffer = [];
    
    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = null;
    }
    
    // Emit batch event for parallel processing
    this.emit('token_batch', batch);
    
    // Also emit individual events for compatibility
    batch.forEach(event => {
      this.emit('token_detected', event);
    });
  }

  /**
   * Emit filter result with performance tracking
   */
  emitFilterResult(mintAddress: string, result: FilterResult): void {
    this.incrementCounter(`filter_${result.filterName.toLowerCase()}`);
    this.emit('filter_result', { mintAddress, result });
  }

  /**
   * Emit trade event with performance tracking
   */
  emitTradeEvent(event: TradeEvent): void {
    this.incrementCounter(`trade_${event.type.toLowerCase()}`);
    this.emit('trade_event', event);
  }

  /**
   * Emit performance metrics
   */
  emitPerformanceMetric(metrics: Partial<PerformanceMetrics>): void {
    this.emit('performance_metric', metrics);
    logPerformanceMetric(metrics);
  }

  /**
   * Get events per second calculation
   */
  getEventsPerSecond(): number {
    const elapsed = (Date.now() - this.lastReset) / 1000;
    const totalEvents = this.getTotalEvents();
    return elapsed > 0 ? Math.round(totalEvents / elapsed) : 0;
  }

  /**
   * Get total event count
   */
  getTotalEvents(): number {
    return Array.from(this.eventCounts.values()).reduce((sum, count) => sum + count, 0);
  }

  /**
   * Get event counts by type
   */
  getEventCounts(): Map<string, number> {
    return new Map(this.eventCounts);
  }

  /**
   * Reset counters and emit performance metrics
   */
  private emitPerformanceMetrics(): void {
    const elapsed = Date.now() - this.lastReset;
    const totalEvents = this.getTotalEvents();
    const eventsPerSecond = elapsed > 0 ? Math.round((totalEvents * 1000) / elapsed) : 0;
    
    const metrics: Partial<PerformanceMetrics> = {
      eventsPerSecond,
      queueDepth: this.batchBuffer.length,
      uptime: elapsed,
      memoryUsage: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
    };
    
    this.emitPerformanceMetric(metrics);
    
    // Reset counters
    this.eventCounts.clear();
    this.lastReset = Date.now();
  }

  /**
   * Increment event counter
   */
  private incrementCounter(event: string): void {
    const current = this.eventCounts.get(event) || 0;
    this.eventCounts.set(event, current + 1);
  }

  /**
   * Cleanup resources
   */
  destroy(): void {
    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
    }
    this.removeAllListeners();
  }
}