import { Connection, Commitment } from '@solana/web3.js';
import { config } from '../config/index.js';
import { RPCHealth } from '../types/index.js';
import { logHealthCheck } from '../utils/logger.js';

/**
 * High-performance RPC manager with connection pooling and health monitoring
 * Supports 10+ RPC endpoints with automatic failover and load balancing
 */
export class RPCManager {
  private connections = new Map<string, Connection>();
  private healthStatus = new Map<string, RPCHealth>();
  private currentIndex = 0;
  private rateLimits = new Map<string, number[]>();
  private requestCounts = new Map<string, number>();
  private readonly HEALTH_CHECK_INTERVAL = 5000; // 5 seconds

  constructor() {
    this.initializeConnections();
    this.startHealthChecks();
    this.startMetricsCollection();
  }

  /**
   * Initialize all RPC connections with keep-alive
   */
  private initializeConnections(): void {
    config.rpcEndpoints.forEach((endpoint, index) => {
      try {
        const connection = new Connection(endpoint, {
          commitment: 'processed' as Commitment,
          confirmTransactionInitialTimeout: config.rpcTimeout,
          wsEndpoint: this.getWebSocketEndpoint(endpoint),
          httpHeaders: {
            'Connection': 'keep-alive',
            'Keep-Alive': 'timeout=30, max=1000'
          }
        });
        
        this.connections.set(endpoint, connection);
        this.healthStatus.set(endpoint, {
          endpoint,
          healthy: true,
          latency: 0,
          errorCount: 0,
          successCount: 0,
          lastCheck: Date.now()
        });
        this.rateLimits.set(endpoint, []);
        this.requestCounts.set(endpoint, 0);
        
        console.log(`✅ RPC ${index + 1} initialized: ${this.maskEndpoint(endpoint)}`);
      } catch (error) {
        console.error(`❌ Failed to initialize RPC ${index + 1}: ${this.maskEndpoint(endpoint)}`, error);
      }
    });
  }

  /**
   * Get WebSocket endpoint from HTTP endpoint
   */
  private getWebSocketEndpoint(httpEndpoint: string): string {
    return httpEndpoint
      .replace('https://', 'wss://')
      .replace('http://', 'ws://');
  }

  /**
   * Mask sensitive parts of endpoint URL
   */
  private maskEndpoint(endpoint: string): string {
    return endpoint.replace(/api-key=[\w-]+/gi, 'api-key=***')
                  .replace(/\/v2\/[\w-]+/gi, '/v2/***');
  }

  /**
   * Start health checks for all RPC endpoints
   */
  private startHealthChecks(): void {
    setInterval(() => {
      this.performHealthChecks().catch(error => {
        console.error('Health check error:', error);
      });
    }, this.HEALTH_CHECK_INTERVAL);
  }

  /**
   * Start metrics collection
   */
  private startMetricsCollection(): void {
    setInterval(() => {
      this.collectMetrics();
    }, 10000); // Every 10 seconds
  }

  /**
   * Perform health checks on all RPC endpoints
   */
  private async performHealthChecks(): Promise<void> {
    const promises = Array.from(this.connections.entries()).map(async ([endpoint, connection]: [string, Connection]) => {
      const start = Date.now();
      try {
        // Use getHealth as a lightweight health check
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3000);
        
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            jsonrpc: '2.0',
            id: 1,
            method: 'getHealth'
          }),
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const latency = Date.now() - start;
        const health = this.healthStatus.get(endpoint)!;
        
        this.healthStatus.set(endpoint, {
          ...health,
          healthy: latency < 3000, // Consider healthy if < 3s
          latency,
          errorCount: Math.max(0, health.errorCount - 1), // Decay error count
          successCount: health.successCount + 1,
          lastCheck: Date.now()
        });
        
        logHealthCheck('RPC', 'healthy', latency);
      } catch (error) {
        const health = this.healthStatus.get(endpoint)!;
        this.healthStatus.set(endpoint, {
          ...health,
          healthy: false,
          latency: 0,
          errorCount: health.errorCount + 1,
          lastCheck: Date.now()
        });
        
        logHealthCheck('RPC', 'unhealthy', 0);
        // Don't log every RPC error to avoid spam, but log critical ones
        if (error instanceof Error && !error.message.includes('timeout') && !error.message.includes('ECONNREFUSED')) {
          console.error(`RPC Health check error for ${endpoint}:`, error.message);
        }
      }
    });

    const results = await Promise.allSettled(promises);
    
    // Check for any rejected promises that might cause issues
    results.forEach((result, index) => {
      if (result.status === 'rejected') {
        const endpoint = Array.from(this.connections.keys())[index];
        console.error(`Health check promise rejected for ${endpoint}:`, result.reason);
      }
    });
  }

  /**
   * Check if endpoint is rate limited
   */
  private isRateLimited(endpoint: string): boolean {
    const now = Date.now();
    const requests = this.rateLimits.get(endpoint) || [];
    const recentRequests = requests.filter(time => now - time < 1000);
    return recentRequests.length >= config.rpcRateLimit;
  }

  /**
   * Add rate limit tracking
   */
  private addRateLimit(endpoint: string): void {
    const now = Date.now();
    const requests = this.rateLimits.get(endpoint) || [];
    requests.push(now);
    
    // Keep only recent requests (last second)
    const recentRequests = requests.filter(time => now - time < 1000);
    this.rateLimits.set(endpoint, recentRequests);
    
    // Increment request count
    const count = this.requestCounts.get(endpoint) || 0;
    this.requestCounts.set(endpoint, count + 1);
  }

  /**
   * Get the best available RPC connection
   * Prioritizes: healthy > low latency > low error rate > round-robin
   */
  getHealthyConnection(): Connection | null {
    // Get healthy endpoints sorted by performance
    const healthyEndpoints = Array.from(this.healthStatus.entries())
      .filter(([_, health]) => health.healthy)
      .sort((a, b) => {
        // Sort by latency first, then error rate
        if (a[1].latency !== b[1].latency) {
          return a[1].latency - b[1].latency;
        }
        return a[1].errorCount - b[1].errorCount;
      })
      .map(([endpoint]) => endpoint);

    // Try to find a non-rate-limited healthy endpoint
    for (const endpoint of healthyEndpoints) {
      if (!this.isRateLimited(endpoint)) {
        this.addRateLimit(endpoint);
        return this.connections.get(endpoint) || null;
      }
    }

    // Fallback to round-robin if all healthy endpoints are rate limited
    const allEndpoints = Array.from(this.connections.keys());
    if (allEndpoints.length === 0) return null;

    this.currentIndex = (this.currentIndex + 1) % allEndpoints.length;
    const endpoint = allEndpoints[this.currentIndex];
    this.addRateLimit(endpoint);
    
    return this.connections.get(endpoint) || null;
  }

  /**
   * Execute batch RPC requests with optimal performance
   */
  async batchRequest<T>(requests: (() => Promise<T>)[]): Promise<(T | null)[]> {
    const batchSize = config.rpcBatchSize;
    const results: (T | null)[] = [];

    for (let i = 0; i < requests.length; i += batchSize) {
      const batch = requests.slice(i, i + batchSize);
      const batchResults = await Promise.allSettled(
        batch.map(async (request) => {
          try {
            return await request();
          } catch (error) {
            console.error('Batch request failed:', error);
            return null;
          }
        })
      );

      results.push(...batchResults.map(result => 
        result.status === 'fulfilled' ? result.value : null
      ));
    }

    return results;
  }

  /**
   * Get all RPC health status
   */
  getHealthStatus(): RPCHealth[] {
    return Array.from(this.healthStatus.values());
  }

  /**
   * Get average latency across healthy connections
   */
  getAverageLatency(): number {
    const healthyConnections = Array.from(this.healthStatus.values())
      .filter(health => health.healthy);
    
    if (healthyConnections.length === 0) return 0;
    
    const totalLatency = healthyConnections.reduce((sum, health) => sum + health.latency, 0);
    return Math.round(totalLatency / healthyConnections.length);
  }

  /**
   * Get total request count across all RPCs
   */
  getTotalRequests(): number {
    return Array.from(this.requestCounts.values()).reduce((sum, count) => sum + count, 0);
  }

  /**
   * Collect and emit metrics
   */
  private collectMetrics(): void {
    const healthyCount = Array.from(this.healthStatus.values())
      .filter(health => health.healthy).length;
    
    const metrics = {
      totalRPCs: this.connections.size,
      healthyRPCs: healthyCount,
      averageLatency: this.getAverageLatency(),
      totalRequests: this.getTotalRequests(),
      requestsPerSecond: this.calculateRequestsPerSecond()
    };
    
    console.log(`📊 RPC Metrics: ${healthyCount}/${this.connections.size} healthy, ${metrics.averageLatency}ms avg latency, ${metrics.requestsPerSecond} req/s`);
  }

  /**
   * Calculate requests per second
   */
  private calculateRequestsPerSecond(): number {
    const now = Date.now();
    const oneSecondAgo = now - 1000;
    
    let totalRecentRequests = 0;
    for (const requests of this.rateLimits.values()) {
      totalRecentRequests += requests.filter(time => time > oneSecondAgo).length;
    }
    
    return totalRecentRequests;
  }

  /**
   * Cleanup resources
   */
  destroy(): void {
    // Close all connections
    for (const _connection of this.connections.values()) {
      // Note: @solana/web3.js doesn't have explicit close method
      // Connections will be garbage collected
    }
    
    this.connections.clear();
    this.healthStatus.clear();
    this.rateLimits.clear();
    this.requestCounts.clear();
  }
}